# Real Scanner Backend (passive checks only, no attacks)
#
# This server runs only on your PC (127.0.0.1:8000, no outside access).
# It does two things:
#   1. Serves the dashboard pages (http://127.0.0.1:8000/)
#   2. Returns JSON for /api/scan with passive homepage header checks
#
# What is checked (passive only):
#   HTTPS, HSTS, CSP, clickjacking protection, nosniff, Referrer-Policy,
#   Permissions-Policy, cookie flags, Server/X-Powered-By info, CORS header.
#
# What NEVER happens:
#   No payloads, SQL injection tries, XSS tries, login tries, form submits,
#   port scans, directory brute force, Cloudflare bypass, no SMS.
#   Active injection testing happens only in labs and authorized bounty
#   programs, never in this tool.
#
# How to run (no extra install needed, just Python):
#   1. Open a terminal in this folder.
#   2. Run: python server.py
#   3. Open http://127.0.0.1:8000/ in a browser.
#   4. On the dashboard, tick the permission box, enter a URL, press START SCAN.
#   5. To stop, press Ctrl+C in the terminal.
#
# Permission gate: the frontend must send authorized=true, otherwise the
# server returns 403. Run it only on your own site or a site you have
# written permission to check. GitHub Pages cannot set custom headers,
# so some headers will show as missing there. That is normal.

import json
import ssl
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
PORT = 8000


def normalize_url(url):
    url = (url or "").strip()
    if not url.startswith("http://") and not url.startswith("https://"):
        url = "https://" + url
    return url


def fetch_homepage(url):
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "Sandip-Real-Scanner (permission-based passive audit)"},
    )
    ctx = ssl.create_default_context()
    try:
        with urllib.request.urlopen(req, timeout=15, context=ctx) as resp:
            return resp.status, resp.geturl(), resp.headers, None
    except urllib.error.HTTPError as e:
        return e.code, e.geturl(), e.headers, "Site returned HTTP %s." % e.code
    except urllib.error.URLError as e:
        return None, url, None, "Could not reach the site: %s" % e.reason
    except Exception as e:  # noqa: BLE001 - beginner tool, needs a clear message
        return None, url, None, "Error: %s" % e


def build_checks(final_url, headers):
    h = {}
    for k, v in headers.items():
        h.setdefault(k.lower(), v)
    cookies = headers.get_all("Set-Cookie") or []

    checks = []

    def add(cid, title, status, detail, fix, severity):
        checks.append(
            {
                "id": cid,
                "title": title,
                "status": status,
                "detail": detail,
                "fix": fix,
                "severity": severity,
            }
        )

    if final_url.startswith("https://"):
        add("https", "HTTPS", "OK", "The site runs on HTTPS.", "", "PASS")
    else:
        add("https", "HTTPS", "MISSING", "The site does not use HTTPS.",
            "Enable HTTPS; without it, data travels unencrypted.", "HIGH")

    if "strict-transport-security" in h:
        add("hsts", "HSTS", "OK", h["strict-transport-security"], "", "PASS")
    else:
        add("hsts", "HSTS", "MISSING", "HSTS header not found.",
            "Add the Strict-Transport-Security header on the server.", "MED")

    if "content-security-policy" in h:
        add("csp", "CSP", "OK", "CSP header found.", "", "PASS")
    else:
        add("csp", "CSP", "MISSING", "CSP header not found.",
            "Add a Content-Security-Policy header; it reduces XSS risk.", "MED")

    frame_ok = "x-frame-options" in h or (
        "content-security-policy" in h and "frame-ancestors" in h["content-security-policy"]
    )
    if frame_ok:
        add("frame", "Clickjacking protection", "OK", "Frame protection found.", "", "PASS")
    else:
        add("frame", "Clickjacking protection", "MISSING", "X-Frame-Options not found.",
            "Add X-Frame-Options: DENY or SAMEORIGIN.", "LOW")

    if h.get("x-content-type-options", "").lower() == "nosniff":
        add("nosniff", "nosniff", "OK", "X-Content-Type-Options: nosniff found.", "", "PASS")
    else:
        add("nosniff", "nosniff", "MISSING", "nosniff not found.",
            "Add X-Content-Type-Options: nosniff.", "LOW")

    if "referrer-policy" in h:
        add("referrer", "Referrer-Policy", "OK", h["referrer-policy"], "", "PASS")
    else:
        add("referrer", "Referrer-Policy", "MISSING", "Referrer-Policy not found.",
            "Add a Referrer-Policy header (for example: strict-origin-when-cross-origin).", "LOW")

    if "permissions-policy" in h:
        add("permissions", "Permissions-Policy", "OK", "Permissions-Policy header found.", "", "PASS")
    else:
        add("permissions", "Permissions-Policy", "MISSING", "Permissions-Policy not found.",
            "Add this header to disable camera/mic/geolocation when not needed. "
            "Example: Permissions-Policy \"camera=(), microphone=(), geolocation=()\"", "LOW")

    if "server" in h:
        add("server", "Server info", "INFO", "Server header: " + h["server"],
            "Hiding the version is better, but on its own this is not a vulnerability.", "INFO")
    else:
        add("server", "Server info", "OK", "No Server header is shown, which is good.", "", "PASS")

    if "x-powered-by" in h:
        add("xpowered", "X-Powered-By", "INFO", "X-Powered-By: " + h["x-powered-by"],
            "Removing it is better, but on its own this is not a vulnerability.", "INFO")
    else:
        add("xpowered", "X-Powered-By", "OK", "No X-Powered-By header is shown, which is good.", "", "PASS")

    if not cookies:
        add("cookies", "Cookies", "OK", "No cookies found.", "", "PASS")
    else:
        bad = [c for c in cookies if "secure" not in c.lower() or "httponly" not in c.lower()]
        if not bad:
            add("cookies", "Cookies", "OK",
                "%d cookies found, all with Secure + HttpOnly." % len(cookies), "", "PASS")
        else:
            add("cookies", "Cookies", "MISSING",
                "%d of %d cookies are missing Secure/HttpOnly." % (len(cookies), len(bad)),
                "Set the Secure and HttpOnly flags on cookies.", "LOW")

    if "access-control-allow-origin" in h:
        add("cors", "CORS header", "INFO",
            "Access-Control-Allow-Origin: " + h["access-control-allow-origin"],
            "With a wildcard (*), any site can read your data. Check this carefully.", "INFO")
    else:
        add("cors", "CORS header", "INFO", "No CORS header found.",
            "This means the site does not allow cross-origin requests, which is often safer.", "INFO")

    return checks


PROFILE_FILTERS = {
    "ssl": ["https", "hsts", "csp", "frame", "nosniff"],
    "full": None,
    "owasp": ["csp", "nosniff", "frame", "cookies"],
    "api": ["https", "cookies", "cors"],
}

PROFILE_NOTES = {
    "ssl": ["This profile checks only SSL and headers."],
    "full": ["This profile runs all passive checks."],
    "owasp": [
        "No injection or XSS payload is sent by this tool.",
        "This profile checks only passive indicators related to XSS (CSP, nosniff, frame, cookies).",
        "Active injection testing happens only in labs and authorized bounty programs.",
    ],
    "api": [
        "Forms are NOT submitted for testing.",
        "This profile checks only the homepage CORS header and cookies.",
    ],
}


def run_scan(url, profile):
    final_url = normalize_url(url)
    status, real_url, headers, error = fetch_homepage(final_url)
    if headers is None:
        return None, error
    all_checks = build_checks(real_url, headers)
    wanted = PROFILE_FILTERS.get(profile, None)
    if wanted is None:
        checks = all_checks
    else:
        checks = [c for c in all_checks if c["id"] in wanted]
    counts = {"CRIT": 0, "HIGH": 0, "MED": 0, "LOW": 0, "PASS": 0, "INFO": 0}
    for c in checks:
        counts[c["severity"]] += 1
    scored = counts["PASS"] + counts["HIGH"] + counts["MED"] + counts["LOW"]
    score = round(100 * counts["PASS"] / scored) if scored else 100
    return {
        "url": final_url,
        "final_url": real_url,
        "status": status,
        "checked_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "profile": profile,
        "score": score,
        "counts": counts,
        "checks": checks,
        "notes": PROFILE_NOTES.get(profile, []),
        "error": error,
    }, None


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):  # keep the terminal clean
        pass

    def send_json(self, code, obj):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if path == "/" or path.endswith(".html"):
            if path == "/":
                target = HERE / "index.html"
            else:
                name = path.lstrip("/")
                if ".." in name or "/" in name:
                    self.send_response(404)
                    self.end_headers()
                    self.wfile.write(b"Not found")
                    return
                target = HERE / name
            if not target.exists():
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b"Page not found. Keep the HTML files in this folder.")
                return
            data = target.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if path == "/api/scan":
            qs = urllib.parse.parse_qs(parsed.query)
            url = (qs.get("url") or [""])[0]
            authorized = (qs.get("authorized") or [""])[0]
            profile = (qs.get("profile") or ["full"])[0]
            if authorized != "true":
                self.send_json(403, {"error": "Permission required. Tick the permission checkbox on the dashboard."})
                return
            if not url.strip():
                self.send_json(400, {"error": "URL is empty."})
                return
            result, err = run_scan(url, profile)
            if result is None:
                self.send_json(502, {"error": err})
                return
            self.send_json(200, result)
            return
        self.send_response(404)
        self.end_headers()
        self.wfile.write(b"Not found")


if __name__ == "__main__":
    print("Real Scanner running at: http://127.0.0.1:%d/" % PORT)
    print("Press Ctrl+C to stop. Run it only on your own or authorized sites.")
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
